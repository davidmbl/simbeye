@extends('simbeye.layout')
@section('content')
    @livewire('simbeye.user')
@endsection
