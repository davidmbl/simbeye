@extends('simbeye.layout-admin')
@section('content')

<div class="row pt-2 mx-5">
    <div class="col-xl-3 col-md-6 pt-3">
        <?php $data = [
            'title' => 'Registered Users',
            'content' => 234 ,
            'sub_title'=>'All Registers Users'
        ]; ?>
        {{-- <a href="#"> --}}
        @include('simbeye.includes.cards.users-card',$data)</a>
    </div>
    <div class="col-xl-3 col-md-6 pt-3">
        <?php $data = [
            'title' => 'Total Searches',
            'content' => 3453,
            'sub_title'=>'All Searches made by users'
        ]; ?>
        @include('simbeye.includes.cards.searches-card',$data)
    </div>
    <div class="col-xl-3 col-md-6 pt-3">
        <?php $data = [
            'title' => 'Total Payments',
            'content' => '3534'.' Tsh',
            'sub_title'=>'All Payments made'
        ]; ?>
        @include('simbeye.includes.cards.payment-card',$data)
    </div>
    <div class="col-xl-3 col-md-6 pt-3">
        <?php $data = [
            'title' => 'Active Subscriptions',
            'content' => 234,
            'sub_title'=>'All active subscriptions'
        ]; ?>
        @include('simbeye.includes.cards.subscriptions-card',$data)
    </div>
</div>

<div class="div mx-5 pt-3">
    <div class="card">
        <div class="card-body">
            <div class="col-xl-6 pt-3">
                <div class="card mb-6 graphCard border-0">
                    <div class="card-header">
                        Searches
                    </div>
                    <div class="card-body border-bottom">
                        {!! $chart->container() !!}
                        {!! $chart->script() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="col-xl-6 pt-3">
                <div class="card mb-6 graphCard border-0">
                    <div class="card-header">
                        Searches
                    </div>
                    <div class="card-body border-bottom">
                        {!! $chart->container() !!}
                        {!! $chart->script() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- <div class="col-xl-6 pt-3">
    <div class="card mb-6 graphCard border-0">
        <div class="card-header">
            User Registrations
        </div>
        <div class="card-body border-bottom">
            {!! $users->container() !!}
            {!! $users->script() !!}
        </div>
    </div>
</div> --}}

    <div class="row pt-5 px-5">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="text-center ">
                <h3>RFID Management</h3>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>

    <div class="row pt-3 px-5">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="float-right mb-4 ">
                @livewire('simbeye.rfid-price')
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>


    <div class="row pt-3 px-5">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="float-right mb-4 ">
                <a href="{{ route('rfid-add') }}" class="btn btn-success btn-sm px-4">ADD</a>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    <div class="row pt-0 px-5">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            @livewire('simbeye.rfid-table')
        </div>
        <div class="col-md-2"></div>
    </div>
@endsection
