@if ()

@endif
<script>
    Swal.fire({
        title: 'Something Went Wrong',
        icon: 'error',
        position: 'top-end',
        toast: true,
        timer: 3000,
        showConfirmButton: false
    })
</script>
