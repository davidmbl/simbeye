<div class="row">
    <div class="col-12">
        <a href="{{ route('rfid-view', $row->id) }}" class="btn btn-outline-secondary btn-sm">
            View
        </a>
    </div>
</div>
